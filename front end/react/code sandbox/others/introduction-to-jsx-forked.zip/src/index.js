import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1>hello world</h1>
    <p>This is a test</p>
  </div>,
  document.getElementById("root")
);
